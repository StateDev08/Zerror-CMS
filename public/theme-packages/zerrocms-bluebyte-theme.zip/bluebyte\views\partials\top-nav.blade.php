@php
    $brand = setting('site_name', config('clan.name'));
@endphp
<header class="bb-nav sticky top-0 z-50">
    <div class="max-w-[1400px] mx-auto px-4 md:px-6 h-13 md:h-14 flex items-center gap-4" style="min-height:3.5rem">
        <a href="{{ url('/') }}" class="flex items-center gap-2.5 shrink-0 group">
            <span class="bb-hex" aria-hidden="true">BB</span>
            <span class="font-display text-base md:text-lg tracking-[0.12em] uppercase text-white group-hover:text-[var(--theme-primary)] transition-colors">
                {{ \Illuminate\Support\Str::limit($brand, 20) }}
            </span>
        </a>
        <nav class="top-nav hidden md:flex flex-1 items-center justify-center gap-5 lg:gap-7">
            <a href="{{ url('/') }}" data-same-tab>{{ __('nav.home') }}</a>
            <a href="{{ route('news.index') }}" data-same-tab>{{ __('nav.news') }}</a>
            <a href="{{ route('roster.index') }}" data-same-tab>{{ __('nav.roster') }}</a>
            <a href="{{ route('calendar.index') }}" data-same-tab>{{ __('nav.calendar') }}</a>
            <a href="{{ route('wiki.index') }}" data-same-tab>{{ __('nav.wiki') }}</a>
            <a href="{{ route('apply.index') }}" data-same-tab>{{ __('nav.apply') }}</a>
            <a href="{{ route('forum.index') }}" data-same-tab>{{ __('nav.forum') }}</a>
        </nav>
        <div class="ml-auto flex items-center gap-3 text-[0.65rem] uppercase tracking-[0.14em]" style="color: var(--theme-muted)">
            @auth
                <a href="{{ route('usercp.index') }}" class="hover:text-white" data-same-tab>{{ __('nav.usercp') }}</a>
                <a href="{{ url('/admin') }}" target="_blank" rel="noopener noreferrer" class="hover:text-white">{{ __('nav.admin') }}</a>
                <form action="{{ route('logout') }}" method="POST" class="inline">@csrf<button type="submit" class="hover:text-white uppercase tracking-[0.14em]">{{ __('auth.logout') }}</button></form>
            @else
                <a href="{{ route('login') }}" class="hover:text-white" data-same-tab>{{ __('auth.login') }}</a>
            @endauth
        </div>
    </div>
</header>
