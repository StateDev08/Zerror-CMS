@extends('theme::layouts.app')

@section('title', setting('site_name', config('clan.name')) . ' - ' . __('nav.home'))

@section('hero')
@php
    $pillars = [
        ['Plugins', 'Erweiterbar', 'M4 4h6v6H4zm10 0h6v6h-6zM4 14h6v6H4zm10 0h6v6h-6z'],
        ['Mods', 'Anpassbar', 'M12 2l3 7h7l-5.5 4.5L18 22l-6-4-6 4 1.5-8.5L2 9h7z'],
        ['Games', 'Community', 'M6 8h12a4 4 0 014 4v2a4 4 0 01-4 4H6a4 4 0 01-4-4v-2a4 4 0 014-4zm2 3h2v2H8zm6 0h2v2h-2z'],
        ['Tools', 'Präzise', 'M14.7 6.3a1 1 0 000 1.4l1.6 1.6a1 1 0 001.4 0l3.77-3.77a6 6 0 01-7.94 7.94l-6.91 6.91a2.12 2.12 0 01-3-3l6.91-6.91a6 6 0 017.94-7.94l-3.76 3.76z'],
        ['Community', 'Verbunden', 'M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2M9 11a4 4 0 100-8 4 4 0 000 8zm8 10v-2a4 4 0 00-3-3.87M16 3.13a4 4 0 010 7.75'],
    ];
@endphp
<section class="relative flex flex-col">
    @include('theme::partials.hero-media')

    <div class="bb-cta-strip relative z-10">
        One community. Endless possibilities.
    </div>

    <div class="values-bar grid grid-cols-2 md:grid-cols-5 relative z-10">
        @foreach($pillars as $p)
            <div class="v-item">
                <div class="bb-icon">
                    <svg class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="{{ $p[2] }}"/></svg>
                </div>
                <p class="text-[0.65rem] md:text-xs font-bold tracking-[0.18em] uppercase" style="color: var(--theme-primary)">{{ $p[0] }}</p>
                <p class="mt-1 text-[0.65rem]" style="color: var(--theme-muted)">{{ $p[1] }}</p>
            </div>
        @endforeach
    </div>
</section>
@endsection

@section('content')
<div class="grid gap-6 lg:grid-cols-[1.45fr_1fr]">
    <section class="panel-box p-5 md:p-7">
        <div class="flex items-end justify-between gap-3 mb-5">
            <h2 class="font-display text-2xl md:text-3xl text-white m-0">{{ __('home.latest_news') }}</h2>
            <a href="{{ route('news.index') }}" class="text-xs uppercase tracking-[0.16em] theme-link-primary">{{ __('nav.news') }} →</a>
        </div>
        @php
            $posts = \App\Models\Post::where('type', 'news')->where('published', true)->orderByDesc('created_at')->limit(5)->get();
        @endphp
        @forelse($posts as $post)
            <a href="{{ route('news.show', $post->slug) }}" class="block py-3.5 border-b last:border-0 transition-all hover:pl-1" style="border-color: color-mix(in srgb, var(--theme-primary) 14%, transparent)" data-same-tab>
                <span class="font-semibold text-white">{{ $post->title }}</span>
                <span class="block text-xs mt-1" style="color: var(--theme-muted)">{{ $post->created_at?->format(__('general.date_format')) }}</span>
            </a>
        @empty
            <p class="text-sm m-0" style="color: var(--theme-muted)">{{ __('home.intro') }}</p>
            <div class="mt-5 flex flex-wrap gap-3">
                <a href="{{ route('apply.index') }}" class="theme-bg-primary px-4 py-2 rounded-lg text-sm uppercase tracking-wider">{{ __('nav.apply') }}</a>
                <a href="{{ route('roster.index') }}" class="px-4 py-2 rounded-lg text-sm uppercase tracking-wider border font-semibold" style="border-color: var(--theme-primary); color: var(--theme-primary)">{{ __('nav.roster') }}</a>
            </div>
        @endempty
    </section>

    <aside class="space-y-4">
        <section class="panel-box p-5">
            <h3 class="font-display text-xl text-white mb-3">Values</h3>
            <ul class="space-y-3 text-sm m-0 p-0 list-none">
                <li class="flex gap-3"><span style="color:var(--theme-primary)">&lt;/&gt;</span><span><strong class="text-white">Clean Code</strong><br><span style="color:var(--theme-muted)">High quality &amp; optimized</span></span></li>
                <li class="flex gap-3"><span style="color:var(--theme-primary)">◈</span><span><strong class="text-white">Reliable</strong><br><span style="color:var(--theme-muted)">Stable &amp; secure</span></span></li>
                <li class="flex gap-3"><span style="color:var(--theme-primary)">◎</span><span><strong class="text-white">Support</strong><br><span style="color:var(--theme-muted)">We are here for you</span></span></li>
                <li class="flex gap-3"><span style="color:var(--theme-primary)">▲</span><span><strong class="text-white">Innovative</strong><br><span style="color:var(--theme-muted)">Always improving</span></span></li>
            </ul>
        </section>
        {!! app(\App\Support\WidgetRenderer::class)->slot('home') !!}
        {!! app(\App\Support\WidgetRenderer::class)->slot('sidebar') !!}
    </aside>
</div>
@endsection
